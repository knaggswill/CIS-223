﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;


namespace Arrays_and_Lists
{
    public partial class Form1 : Form
    {
        private List<string> teams;
        private List<string> winners;
        public Form1()
        {
            InitializeComponent();
            LoadTeams();
            LoadWinners();
            PopulateListBox();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //null
        }
        private void LoadTeams()
        {
            teams = new List<string>();
            try
            {
                using (StreamReader reader = new StreamReader("Teams.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        teams.Add(line.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading teams: " + ex.Message);
            }
        }
        private void LoadWinners()
        {
            winners = new List<string>();
            try
            {
                using (StreamReader reader = new StreamReader("WorldSeriesWinners.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        winners.Add(line.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading winners: " + ex.Message);
            }
        }
        private void PopulateListBox()
        {
            foreach (var team in teams)
            {
                listBoxTeams.Items.Add(team);
            }
        }
        private void listBoxTeams_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxTeams.SelectedItem != null)
            {
                string selectedTeam = listBoxTeams.SelectedItem.ToString();
                int winCount = CountWorldSeriesWins(selectedTeam);
                if (winCount > 0)
                {
                    textBoxWins.Text = $"{selectedTeam} has won the World Series {winCount} times.";
                }
                else
                {
                    textBoxWins.Text = $"{selectedTeam} has not won the World Series.";
                }
            }
        }
        private int CountWorldSeriesWins(string team)
        {
            int count = 0;
            foreach (var winner in winners)
            {
                if (winner.Equals(team, StringComparison.OrdinalIgnoreCase))
                {
                    count++;
                }
            }
            return count;
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}

//https://www.youtube.com/watch?v=dQw4w9WgXcQ











