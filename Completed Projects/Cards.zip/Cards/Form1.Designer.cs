﻿namespace Cards
{
    partial class DirectionsLabel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DirectionsLabel));
            this.backcardpictureBox = new System.Windows.Forms.PictureBox();
            this.facecardpictureBox = new System.Windows.Forms.PictureBox();
            this.CardNameLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.backcardpictureBox3 = new System.Windows.Forms.PictureBox();
            this.backcardpictureBox2 = new System.Windows.Forms.PictureBox();
            this.backcardpictureBox5 = new System.Windows.Forms.PictureBox();
            this.backcardpictureBox4 = new System.Windows.Forms.PictureBox();
            this.facecardpictureBox5 = new System.Windows.Forms.PictureBox();
            this.facecardpictureBox3 = new System.Windows.Forms.PictureBox();
            this.facecardpictureBox4 = new System.Windows.Forms.PictureBox();
            this.facecardpictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // backcardpictureBox
            // 
            this.backcardpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("backcardpictureBox.Image")));
            this.backcardpictureBox.Location = new System.Drawing.Point(342, 96);
            this.backcardpictureBox.Name = "backcardpictureBox";
            this.backcardpictureBox.Size = new System.Drawing.Size(124, 169);
            this.backcardpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backcardpictureBox.TabIndex = 0;
            this.backcardpictureBox.TabStop = false;
            this.backcardpictureBox.Click += new System.EventHandler(this.backcardpictureBox_Click);
            // 
            // facecardpictureBox
            // 
            this.facecardpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("facecardpictureBox.Image")));
            this.facecardpictureBox.Location = new System.Drawing.Point(342, 96);
            this.facecardpictureBox.Name = "facecardpictureBox";
            this.facecardpictureBox.Size = new System.Drawing.Size(124, 169);
            this.facecardpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.facecardpictureBox.TabIndex = 1;
            this.facecardpictureBox.TabStop = false;
            this.facecardpictureBox.Click += new System.EventHandler(this.facecardpictureBox_Click);
            // 
            // CardNameLabel
            // 
            this.CardNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CardNameLabel.Location = new System.Drawing.Point(549, 324);
            this.CardNameLabel.Name = "CardNameLabel";
            this.CardNameLabel.Size = new System.Drawing.Size(245, 41);
            this.CardNameLabel.TabIndex = 2;
            this.CardNameLabel.Click += new System.EventHandler(this.CardNameLabel_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(586, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 59);
            this.label1.TabIndex = 3;
            this.label1.Text = "Flip the cards over";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(675, 383);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(119, 44);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(549, 383);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(119, 44);
            this.ResetButton.TabIndex = 5;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // backcardpictureBox3
            // 
            this.backcardpictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("backcardpictureBox3.Image")));
            this.backcardpictureBox3.Location = new System.Drawing.Point(633, 96);
            this.backcardpictureBox3.Name = "backcardpictureBox3";
            this.backcardpictureBox3.Size = new System.Drawing.Size(124, 169);
            this.backcardpictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backcardpictureBox3.TabIndex = 6;
            this.backcardpictureBox3.TabStop = false;
            this.backcardpictureBox3.Click += new System.EventHandler(this.backcardpictureBox3_Click);
            // 
            // backcardpictureBox2
            // 
            this.backcardpictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("backcardpictureBox2.Image")));
            this.backcardpictureBox2.Location = new System.Drawing.Point(486, 96);
            this.backcardpictureBox2.Name = "backcardpictureBox2";
            this.backcardpictureBox2.Size = new System.Drawing.Size(124, 169);
            this.backcardpictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backcardpictureBox2.TabIndex = 7;
            this.backcardpictureBox2.TabStop = false;
            this.backcardpictureBox2.Click += new System.EventHandler(this.backcardpictureBox2_Click);
            // 
            // backcardpictureBox5
            // 
            this.backcardpictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("backcardpictureBox5.Image")));
            this.backcardpictureBox5.Location = new System.Drawing.Point(939, 96);
            this.backcardpictureBox5.Name = "backcardpictureBox5";
            this.backcardpictureBox5.Size = new System.Drawing.Size(124, 169);
            this.backcardpictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backcardpictureBox5.TabIndex = 8;
            this.backcardpictureBox5.TabStop = false;
            this.backcardpictureBox5.Click += new System.EventHandler(this.backcardpictureBox5_Click);
            // 
            // backcardpictureBox4
            // 
            this.backcardpictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("backcardpictureBox4.Image")));
            this.backcardpictureBox4.Location = new System.Drawing.Point(785, 96);
            this.backcardpictureBox4.Name = "backcardpictureBox4";
            this.backcardpictureBox4.Size = new System.Drawing.Size(124, 169);
            this.backcardpictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backcardpictureBox4.TabIndex = 9;
            this.backcardpictureBox4.TabStop = false;
            this.backcardpictureBox4.Click += new System.EventHandler(this.backcardpictureBox4_Click);
            // 
            // facecardpictureBox5
            // 
            this.facecardpictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("facecardpictureBox5.Image")));
            this.facecardpictureBox5.Location = new System.Drawing.Point(939, 96);
            this.facecardpictureBox5.Name = "facecardpictureBox5";
            this.facecardpictureBox5.Size = new System.Drawing.Size(124, 169);
            this.facecardpictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.facecardpictureBox5.TabIndex = 10;
            this.facecardpictureBox5.TabStop = false;
            this.facecardpictureBox5.Click += new System.EventHandler(this.facecardpictureBox5_Click);
            // 
            // facecardpictureBox3
            // 
            this.facecardpictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("facecardpictureBox3.Image")));
            this.facecardpictureBox3.Location = new System.Drawing.Point(633, 96);
            this.facecardpictureBox3.Name = "facecardpictureBox3";
            this.facecardpictureBox3.Size = new System.Drawing.Size(124, 169);
            this.facecardpictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.facecardpictureBox3.TabIndex = 11;
            this.facecardpictureBox3.TabStop = false;
            this.facecardpictureBox3.Click += new System.EventHandler(this.facecardpictureBox3_Click);
            // 
            // facecardpictureBox4
            // 
            this.facecardpictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("facecardpictureBox4.Image")));
            this.facecardpictureBox4.Location = new System.Drawing.Point(785, 96);
            this.facecardpictureBox4.Name = "facecardpictureBox4";
            this.facecardpictureBox4.Size = new System.Drawing.Size(124, 169);
            this.facecardpictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.facecardpictureBox4.TabIndex = 12;
            this.facecardpictureBox4.TabStop = false;
            this.facecardpictureBox4.Click += new System.EventHandler(this.facecardpictureBox4_Click);
            // 
            // facecardpictureBox2
            // 
            this.facecardpictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("facecardpictureBox2.Image")));
            this.facecardpictureBox2.Location = new System.Drawing.Point(486, 96);
            this.facecardpictureBox2.Name = "facecardpictureBox2";
            this.facecardpictureBox2.Size = new System.Drawing.Size(124, 169);
            this.facecardpictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.facecardpictureBox2.TabIndex = 13;
            this.facecardpictureBox2.TabStop = false;
            this.facecardpictureBox2.Click += new System.EventHandler(this.facecardpictureBox2_Click);
            // 
            // DirectionsLabel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1241, 696);
            this.Controls.Add(this.backcardpictureBox5);
            this.Controls.Add(this.backcardpictureBox4);
            this.Controls.Add(this.backcardpictureBox3);
            this.Controls.Add(this.backcardpictureBox2);
            this.Controls.Add(this.facecardpictureBox2);
            this.Controls.Add(this.facecardpictureBox4);
            this.Controls.Add(this.facecardpictureBox3);
            this.Controls.Add(this.facecardpictureBox5);
            this.Controls.Add(this.backcardpictureBox);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CardNameLabel);
            this.Controls.Add(this.facecardpictureBox);
            this.Name = "DirectionsLabel";
            this.Text = "Card Game";
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backcardpictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facecardpictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox backcardpictureBox;
        private System.Windows.Forms.PictureBox facecardpictureBox;
        private System.Windows.Forms.Label CardNameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.PictureBox backcardpictureBox3;
        private System.Windows.Forms.PictureBox backcardpictureBox2;
        private System.Windows.Forms.PictureBox backcardpictureBox5;
        private System.Windows.Forms.PictureBox backcardpictureBox4;
        private System.Windows.Forms.PictureBox facecardpictureBox5;
        private System.Windows.Forms.PictureBox facecardpictureBox3;
        private System.Windows.Forms.PictureBox facecardpictureBox4;
        private System.Windows.Forms.PictureBox facecardpictureBox2;
    }
}

