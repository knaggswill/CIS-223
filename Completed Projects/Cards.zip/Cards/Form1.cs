﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cards
{
    public partial class DirectionsLabel : Form
    {
        public DirectionsLabel()
        {
            InitializeComponent();
        }

        private void facecardpictureBox_Click(object sender, EventArgs e)
        {
           //Void
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            CardNameLabel.Text = "";
            backcardpictureBox.Visible = true;
            backcardpictureBox2.Visible = true;
            backcardpictureBox3.Visible = true;
            backcardpictureBox4.Visible = true;
            backcardpictureBox5.Visible = true;
        }

        private void backcardpictureBox_Click(object sender, EventArgs e)
        {
            backcardpictureBox.Visible = false;
            CardNameLabel.Text = "Jack of Hearts";
        }

        private void backcardpictureBox2_Click(object sender, EventArgs e)
        {
            backcardpictureBox2.Visible = false;
            CardNameLabel.Text = "Five of Hearts";
        }

        private void backcardpictureBox3_Click(object sender, EventArgs e)
        {
            backcardpictureBox3.Visible = false;
            CardNameLabel.Text = "Seven of Clubs";
        }

        private void backcardpictureBox4_Click(object sender, EventArgs e)
        {
            backcardpictureBox4.Visible = false;
            CardNameLabel.Text = "Ten of Spades";
        }

        private void backcardpictureBox5_Click(object sender, EventArgs e)
        {
            backcardpictureBox5.Visible = false;
            CardNameLabel.Text = "Four of Diamonds";
        }

        private void facecardpictureBox2_Click(object sender, EventArgs e)
        {
            //Void
        }

        private void facecardpictureBox3_Click(object sender, EventArgs e)
        {
           //Void
        }

        private void facecardpictureBox4_Click(object sender, EventArgs e)
        {
           //Void
        }

        private void facecardpictureBox5_Click(object sender, EventArgs e)
        {
           //Void
        }

        private void CardNameLabel_Click(object sender, EventArgs e)
        {
           //Void
        }
    }
}
