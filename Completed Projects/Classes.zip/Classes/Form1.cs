﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    public partial class Form1 : Form
    {
        private Vehicle myCar;

        public Form1()
        {
            InitializeComponent();
            myCar = new Vehicle(2024, "Toyota", "Camry");
            UpdateSpeedDisplay();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Null
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            {
                myCar.Accelerate();
                UpdateSpeedDisplay();
            }

        }
        private void brakeButton_Click(object sender, EventArgs e)
        {
            {
                myCar.Brake();
                UpdateSpeedDisplay();
            }
        }
        private void UpdateSpeedDisplay()
        {
            speedLabel.Text = $"Speed {myCar.Speed} mph";
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

//Almost there
