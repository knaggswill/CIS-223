﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{ 
    internal class Vehicle

    {
            public int Year { get; private set; }
            public string Make { get; private set; }
            public string Model { get; private set; }
            public int Speed { get; private set; }
            public Vehicle(int year, string make, string model)

            {
                Year = year;
                Make = make;
                Model = model;
                Speed = 0;
            }
            public void Accelerate()
            {
                if (Speed < 120)
                {
                    Speed += 5;
                    if (Speed > 120)
                        Speed = 120;
                }
            }
            public void Brake()
            {
                if (Speed > 0)
                {
                    Speed -= 5;
                    if (Speed < 0)
                        Speed = 0;
                }
            }
        
    }
}

//Word of the day: Menial - (of work) not requiring much skill and lacking prestige.
