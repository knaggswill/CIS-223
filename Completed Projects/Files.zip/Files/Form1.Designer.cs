﻿namespace Files
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxInpatient = new System.Windows.Forms.ListBox();
            this.listBoxOutpatient = new System.Windows.Forms.ListBox();
            this.labelInpatientCount = new System.Windows.Forms.Label();
            this.labelOutpatientCount = new System.Windows.Forms.Label();
            this.labelGrandTotal = new System.Windows.Forms.Label();
            this.btnLoadData = new System.Windows.Forms.Button();
            this.labelTotalOutpatientCharges = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.InPatientIndividualChargesLabel = new System.Windows.Forms.Label();
            this.OutPatientIndividualChargesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBoxInpatient
            // 
            this.listBoxInpatient.FormattingEnabled = true;
            this.listBoxInpatient.ItemHeight = 20;
            this.listBoxInpatient.Location = new System.Drawing.Point(233, 119);
            this.listBoxInpatient.Name = "listBoxInpatient";
            this.listBoxInpatient.Size = new System.Drawing.Size(255, 424);
            this.listBoxInpatient.TabIndex = 0;
            // 
            // listBoxOutpatient
            // 
            this.listBoxOutpatient.FormattingEnabled = true;
            this.listBoxOutpatient.ItemHeight = 20;
            this.listBoxOutpatient.Location = new System.Drawing.Point(542, 121);
            this.listBoxOutpatient.Name = "listBoxOutpatient";
            this.listBoxOutpatient.Size = new System.Drawing.Size(258, 424);
            this.listBoxOutpatient.TabIndex = 1;
            // 
            // labelInpatientCount
            // 
            this.labelInpatientCount.AutoSize = true;
            this.labelInpatientCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelInpatientCount.Location = new System.Drawing.Point(233, 580);
            this.labelInpatientCount.Name = "labelInpatientCount";
            this.labelInpatientCount.Size = new System.Drawing.Size(79, 22);
            this.labelInpatientCount.TabIndex = 2;
            this.labelInpatientCount.Text = "In Patient";
            // 
            // labelOutpatientCount
            // 
            this.labelOutpatientCount.AutoSize = true;
            this.labelOutpatientCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelOutpatientCount.Location = new System.Drawing.Point(542, 580);
            this.labelOutpatientCount.Name = "labelOutpatientCount";
            this.labelOutpatientCount.Size = new System.Drawing.Size(91, 22);
            this.labelOutpatientCount.TabIndex = 3;
            this.labelOutpatientCount.Text = "Out Patient";
            // 
            // labelGrandTotal
            // 
            this.labelGrandTotal.AutoSize = true;
            this.labelGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelGrandTotal.Location = new System.Drawing.Point(233, 634);
            this.labelGrandTotal.Name = "labelGrandTotal";
            this.labelGrandTotal.Size = new System.Drawing.Size(143, 22);
            this.labelGrandTotal.TabIndex = 4;
            this.labelGrandTotal.Text = "In Patient Charges";
            // 
            // btnLoadData
            // 
            this.btnLoadData.Location = new System.Drawing.Point(857, 279);
            this.btnLoadData.Name = "btnLoadData";
            this.btnLoadData.Size = new System.Drawing.Size(147, 68);
            this.btnLoadData.TabIndex = 6;
            this.btnLoadData.Text = "Run Bills";
            this.btnLoadData.UseVisualStyleBackColor = true;
            this.btnLoadData.Click += new System.EventHandler(this.btnLoadData_Click);
            // 
            // labelTotalOutpatientCharges
            // 
            this.labelTotalOutpatientCharges.AutoSize = true;
            this.labelTotalOutpatientCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTotalOutpatientCharges.Location = new System.Drawing.Point(542, 634);
            this.labelTotalOutpatientCharges.Name = "labelTotalOutpatientCharges";
            this.labelTotalOutpatientCharges.Size = new System.Drawing.Size(155, 22);
            this.labelTotalOutpatientCharges.TabIndex = 7;
            this.labelTotalOutpatientCharges.Text = "Out Patient Charges";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(857, 353);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(147, 73);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // InPatientIndividualChargesLabel
            // 
            this.InPatientIndividualChargesLabel.AutoSize = true;
            this.InPatientIndividualChargesLabel.Location = new System.Drawing.Point(229, 78);
            this.InPatientIndividualChargesLabel.Name = "InPatientIndividualChargesLabel";
            this.InPatientIndividualChargesLabel.Size = new System.Drawing.Size(212, 20);
            this.InPatientIndividualChargesLabel.TabIndex = 9;
            this.InPatientIndividualChargesLabel.Text = "In-Patient Individual Charges";
            // 
            // OutPatientIndividualChargesLabel
            // 
            this.OutPatientIndividualChargesLabel.AutoSize = true;
            this.OutPatientIndividualChargesLabel.Location = new System.Drawing.Point(538, 78);
            this.OutPatientIndividualChargesLabel.Name = "OutPatientIndividualChargesLabel";
            this.OutPatientIndividualChargesLabel.Size = new System.Drawing.Size(224, 20);
            this.OutPatientIndividualChargesLabel.TabIndex = 10;
            this.OutPatientIndividualChargesLabel.Text = "Out-Patient Individual Charges";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1099, 750);
            this.Controls.Add(this.OutPatientIndividualChargesLabel);
            this.Controls.Add(this.InPatientIndividualChargesLabel);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.labelTotalOutpatientCharges);
            this.Controls.Add(this.btnLoadData);
            this.Controls.Add(this.labelGrandTotal);
            this.Controls.Add(this.labelOutpatientCount);
            this.Controls.Add(this.labelInpatientCount);
            this.Controls.Add(this.listBoxOutpatient);
            this.Controls.Add(this.listBoxInpatient);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxInpatient;
        private System.Windows.Forms.ListBox listBoxOutpatient;
        private System.Windows.Forms.Label labelInpatientCount;
        private System.Windows.Forms.Label labelOutpatientCount;
        private System.Windows.Forms.Label labelGrandTotal;
        private System.Windows.Forms.Button btnLoadData;
        private System.Windows.Forms.Label labelTotalOutpatientCharges;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label InPatientIndividualChargesLabel;
        private System.Windows.Forms.Label OutPatientIndividualChargesLabel;
    }
}

