﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            {

                string executablePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(executablePath, "HospitalBillingData.txt");

                if (!File.Exists(filePath))
                {
                    MessageBox.Show("File not found.");
                    return;
                }
                double totalInpatientCharges = 0;
                double totalOutpatientCharges = 0;
                int inpatientCount = 0;
                int outpatientCount = 0;
                double grandTotalCharges = 0;

                listBoxInpatient.Items.Clear();
                listBoxOutpatient.Items.Clear();

                using (StreamReader reader = new StreamReader(filePath))
                {
                    while (!reader.EndOfStream)
                    {
                        
                        char transCode = (char)reader.Read();
                        reader.ReadLine(); // To move to the next line

                        
                        string line = reader.ReadLine();
                        int numberOfDays = int.Parse(line);

                        
                        line = reader.ReadLine();
                        double rate = double.Parse(line);

                        
                        line = reader.ReadLine();
                        double charges = double.Parse(line);

                        
                        double totalCharges = 0;

                        if (transCode == 'I') // In-patient
                        {
                            totalCharges = (numberOfDays * rate) + charges;
                            listBoxInpatient.Items.Add(totalCharges);
                            totalInpatientCharges += totalCharges;
                            inpatientCount++;
                        }
                        else if (transCode == 'O') // Out-patient
                        {
                            totalCharges = rate + charges;
                            listBoxOutpatient.Items.Add(totalCharges);
                            totalOutpatientCharges += totalCharges;
                            outpatientCount++;
                        }

                        grandTotalCharges += totalCharges;

                    }
                }

                
                labelInpatientCount.Text = $"In-patient Count: {inpatientCount}";
                labelOutpatientCount.Text = $"Out-patient Count: {outpatientCount}";
                labelGrandTotal.Text = $"Grand Total Charges: {grandTotalCharges:C}";
                labelTotalOutpatientCharges.Text = $"Total Outpatient Charges: {totalOutpatientCharges:C}";

            }
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
//Fomulas differ, however end result is the same. Program fufills critea explained in assignment portion of this module.