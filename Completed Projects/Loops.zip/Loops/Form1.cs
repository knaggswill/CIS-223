﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //null
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            lstDistances.Items.Clear();
            if (double.TryParse(txtSpeed.Text, out double speed) &&
                int.TryParse(txtTime.Text, out int time) && time >= 3)
            {
                for (int hour = 1; hour <= time; hour++)
                {
                    double distance = speed * hour;
                    lstDistances.Items.Add($"After hour {hour} the distance is {distance} miles");
                }
            }
            else
            {
                MessageBox.Show("Please enter valid speed and time (minimum 3 hours).", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
        
