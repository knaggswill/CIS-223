﻿namespace Making_Decisions_and_Random_Numbers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonHelp = new System.Windows.Forms.Button();
            this.buttonHint = new System.Windows.Forms.Button();
            this.textBoxGuess = new System.Windows.Forms.TextBox();
            this.labelFeedback = new System.Windows.Forms.Label();
            this.buttonGuess = new System.Windows.Forms.Button();
            this.labelPrompt = new System.Windows.Forms.Label();
            this.labelTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(55, 41);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(76, 47);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
//            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click_1);
            // 
            // buttonHelp
            // 
            this.buttonHelp.Location = new System.Drawing.Point(55, 94);
            this.buttonHelp.Name = "buttonHelp";
            this.buttonHelp.Size = new System.Drawing.Size(76, 44);
            this.buttonHelp.TabIndex = 1;
            this.buttonHelp.Text = "Help!";
            this.buttonHelp.UseVisualStyleBackColor = true;
          this.buttonHelp.Click += new System.EventHandler(this.buttonHelp_Click_1);
            // 
            // buttonHint
            // 
            this.buttonHint.Location = new System.Drawing.Point(55, 154);
            this.buttonHint.Name = "buttonHint";
            this.buttonHint.Size = new System.Drawing.Size(74, 42);
            this.buttonHint.TabIndex = 2;
            this.buttonHint.Text = "Hint";
            this.buttonHint.UseVisualStyleBackColor = true;
            this.buttonHint.Click += new System.EventHandler(this.buttonHint_Click_1);
            // 
            // textBoxGuess
            // 
            this.textBoxGuess.Location = new System.Drawing.Point(174, 51);
            this.textBoxGuess.Name = "textBoxGuess";
            this.textBoxGuess.Size = new System.Drawing.Size(107, 26);
            this.textBoxGuess.TabIndex = 3;
            this.textBoxGuess.TextChanged += new System.EventHandler(this.textBoxGuess_TextChanged);
            // 
            // labelFeedback
            // 
            this.labelFeedback.AutoSize = true;
            this.labelFeedback.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFeedback.Location = new System.Drawing.Point(318, 55);
            this.labelFeedback.Name = "labelFeedback";
            this.labelFeedback.Size = new System.Drawing.Size(82, 22);
            this.labelFeedback.TabIndex = 5;
            this.labelFeedback.Text = "Feedback";
            this.labelFeedback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
          this.labelFeedback.Click += new System.EventHandler(this.labelFeedback_Click);
            // 
            // buttonGuess
            // 
            this.buttonGuess.Location = new System.Drawing.Point(55, 211);
            this.buttonGuess.Name = "buttonGuess";
            this.buttonGuess.Size = new System.Drawing.Size(73, 42);
            this.buttonGuess.TabIndex = 6;
            this.buttonGuess.Text = "Guess";
            this.buttonGuess.UseVisualStyleBackColor = true;
           this.buttonGuess.Click += new System.EventHandler(this.buttonGuess_Click_1);
            // 
            // labelPrompt
            // 
            this.labelPrompt.AutoSize = true;
            this.labelPrompt.Location = new System.Drawing.Point(334, 106);
            this.labelPrompt.Name = "labelPrompt";
            this.labelPrompt.Size = new System.Drawing.Size(60, 20);
            this.labelPrompt.TabIndex = 7;
            this.labelPrompt.Text = "Prompt";
            this.labelPrompt.Click += new System.EventHandler(this.labelPrompt_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Location = new System.Drawing.Point(571, 176);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(38, 20);
            this.labelTitle.TabIndex = 8;
            this.labelTitle.Text = "Title";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.labelPrompt);
            this.Controls.Add(this.buttonGuess);
            this.Controls.Add(this.labelFeedback);
            this.Controls.Add(this.textBoxGuess);
            this.Controls.Add(this.buttonHint);
            this.Controls.Add(this.buttonHelp);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonHelp;
        private System.Windows.Forms.Button buttonHint;
        private System.Windows.Forms.TextBox textBoxGuess;
        private System.Windows.Forms.Label labelFeedback;
        private System.Windows.Forms.Button buttonGuess;
        private System.Windows.Forms.Label labelPrompt;
        private System.Windows.Forms.Label labelTitle;
    }
}

