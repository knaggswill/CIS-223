﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Making_Decisions_and_Random_Numbers
{
    public partial class Form1 : Form
    {
        private int targetNumber;
        private Random random;
        public Form1()
        {
            InitializeComponent();
            random = new Random();
            StartNewGame();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ClientSize = new System.Drawing.Size(284, 161);
            this.Controls.Add(this.labelFeedback);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonHelp);
            this.Controls.Add(this.buttonHint);
            this.Controls.Add(this.buttonGuess);
            this.Controls.Add(this.textBoxGuess);
            this.Controls.Add(this.labelPrompt);
            this.Controls.Add(this.labelTitle);
            this.Name = "Form1";
            this.Text = "Guessing Game";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        private void StartNewGame()
        {
            targetNumber = random.Next(1, 101); // Random number between 1 and 100
            labelFeedback.Text = "Guess a number between 1 and 100!";
            textBoxGuess.Clear();
            textBoxGuess.Focus();
        }

        private void buttonGuess_Click(object sender, EventArgs e)
        {
            int guess;
            bool isNumber = int.TryParse(textBoxGuess.Text, out guess);

            if (!isNumber)
            {
                labelFeedback.Text = "Please enter a valid number.";
                // Optionally set an error graphic
                return;
            }

            if (guess < 1 || guess > 100)
            {
                labelFeedback.Text = "Please enter a number between 1 and 100.";
                // Optionally set an error graphic
                return;
            }

            if (guess < targetNumber)
            {
                labelFeedback.Text = "Too low! Try again.";
                // Optionally set a low graphic
            }
            else if (guess > targetNumber)
            {
                labelFeedback.Text = "Too high! Try again.";
                // Optionally set a high graphic
            }
            else
            {
                labelFeedback.Text = "Congratulations! You guessed the number!";
                // Optionally set a success graphic
                if (MessageBox.Show("Want to play the game again?", "Play Again", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    StartNewGame();
                }
                else
                {
                    Application.Exit();
                }
            }

            textBoxGuess.Clear();
            textBoxGuess.Focus();
        }

        private void buttonHint_Click(object sender, EventArgs e)
        {
            int lowerBound = targetNumber - 10;
            int upperBound = targetNumber + 10;
            lowerBound = lowerBound < 1 ? 1 : lowerBound;
            upperBound = upperBound > 100 ? 100 : upperBound;

            this.buttonHint.Location = new System.Drawing.Point(15, 100);
            this.buttonHint.Name = "buttonHint";
            this.buttonHint.Size = new System.Drawing.Size(75, 23);
            this.buttonHint.TabIndex = 4;
            this.buttonHint.Text = "Hint";
            this.buttonHint.UseVisualStyleBackColor = true;
            this.buttonHint.Click += new System.EventHandler(this.buttonHint_Click);

            

            MessageBox.Show($"The number is between {lowerBound} and {upperBound}.", "Hint");
        }


        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();

            this.buttonExit.Name = "buttonExit";
            this.buttonExit.TabIndex = 6;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);


        }

        private void labelPrompt_Click(object sender, EventArgs e)
        {
            this.labelPrompt.AutoSize = true;

            this.labelPrompt.Name = "labelPrompt";
            this.labelPrompt.TabIndex = 1;
            this.labelPrompt.Text = "Enter your guess between 1 and 100:";

        }

        private void textBoxGuess_TextChanged(object sender, EventArgs e)
        {

            this.textBoxGuess.Name = "textBoxGuess";
            this.textBoxGuess.TabIndex = 2;
        }

    }
}