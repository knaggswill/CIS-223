﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modularization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //void
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
           
            if (double.TryParse(textBoxSideLength.Text, out double sideLength))
            {
                if (sideLength <= 0)
                {
                    MessageBox.Show("Please enter a positive number.");
                    return;
                }
                double surfaceAreaOneSide = CalculateSurfaceAreaOneSide(sideLength);
                double surfaceAreaWholeCube = CalculateSurfaceAreaWholeCube(sideLength, surfaceAreaOneSide);
                double volume = CalculateVolume(sideLength);
                labelSurfaceAreaOneSide.Text = $"Surface Area of just One Side: {surfaceAreaOneSide:F2} square units";
                labelSurfaceAreaWholeCube.Text = $"Surface Area of the Whole Cube: {surfaceAreaWholeCube:F2} square units";
                labelVolume.Text = $"Volume: {volume:F2} cubic units";
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter an int value.");
            }
        }
        private double CalculateSurfaceAreaOneSide(double sideLength)
        {
            double surfaceArea = sideLength * sideLength;
            return surfaceArea;
        }
        private double CalculateSurfaceAreaWholeCube(double sideLength, double surfaceAreaOneSide)
        {
            double surfaceAreaWholeCube = 6 * surfaceAreaOneSide;
            return surfaceAreaWholeCube;
        }
        private double CalculateVolume(double sideLength)
        {
            double volume = Math.Pow(sideLength, 3);
            MessageBox.Show($"Volume: {volume:F2} cubic units", "Cube Volume");
            return volume;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
//Happy Labor Day!