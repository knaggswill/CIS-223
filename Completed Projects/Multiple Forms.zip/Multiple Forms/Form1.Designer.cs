﻿namespace Multiple_Forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBoxStore = new System.Windows.Forms.PictureBox();
            this.radioButtonOneScoop = new System.Windows.Forms.RadioButton();
            this.radioButtonTwoScoop = new System.Windows.Forms.RadioButton();
            this.radioButtonThreeScoop = new System.Windows.Forms.RadioButton();
            this.comboBoxFlavors = new System.Windows.Forms.ComboBox();
            this.checkBoxNuts = new System.Windows.Forms.CheckBox();
            this.checkBoxWhippedCream = new System.Windows.Forms.CheckBox();
            this.checkBoxCherries = new System.Windows.Forms.CheckBox();
            this.buttonOrderNow = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelFlavor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStore)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxStore
            // 
            this.pictureBoxStore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxStore.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStore.Image")));
            this.pictureBoxStore.Location = new System.Drawing.Point(33, 22);
            this.pictureBoxStore.Name = "pictureBoxStore";
            this.pictureBoxStore.Size = new System.Drawing.Size(97, 95);
            this.pictureBoxStore.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStore.TabIndex = 0;
            this.pictureBoxStore.TabStop = false;
            // 
            // radioButtonOneScoop
            // 
            this.radioButtonOneScoop.AutoSize = true;
            this.radioButtonOneScoop.Location = new System.Drawing.Point(149, 22);
            this.radioButtonOneScoop.Name = "radioButtonOneScoop";
            this.radioButtonOneScoop.Size = new System.Drawing.Size(137, 24);
            this.radioButtonOneScoop.TabIndex = 1;
            this.radioButtonOneScoop.TabStop = true;
            this.radioButtonOneScoop.Text = "1 Scoop $2.20";
            this.radioButtonOneScoop.UseVisualStyleBackColor = true;
            // 
            // radioButtonTwoScoop
            // 
            this.radioButtonTwoScoop.AutoSize = true;
            this.radioButtonTwoScoop.Location = new System.Drawing.Point(149, 52);
            this.radioButtonTwoScoop.Name = "radioButtonTwoScoop";
            this.radioButtonTwoScoop.Size = new System.Drawing.Size(145, 24);
            this.radioButtonTwoScoop.TabIndex = 2;
            this.radioButtonTwoScoop.TabStop = true;
            this.radioButtonTwoScoop.Text = "2 Scoops $3.00";
            this.radioButtonTwoScoop.UseVisualStyleBackColor = true;
            // 
            // radioButtonThreeScoop
            // 
            this.radioButtonThreeScoop.AutoSize = true;
            this.radioButtonThreeScoop.Location = new System.Drawing.Point(149, 82);
            this.radioButtonThreeScoop.Name = "radioButtonThreeScoop";
            this.radioButtonThreeScoop.Size = new System.Drawing.Size(145, 24);
            this.radioButtonThreeScoop.TabIndex = 3;
            this.radioButtonThreeScoop.TabStop = true;
            this.radioButtonThreeScoop.Text = "3 Scoops $4.00";
            this.radioButtonThreeScoop.UseVisualStyleBackColor = true;
            // 
            // comboBoxFlavors
            // 
            this.comboBoxFlavors.FormattingEnabled = true;
            this.comboBoxFlavors.Items.AddRange(new object[] {
            "Chocolate",
            "Strawberry",
            "Vanilla"});
            this.comboBoxFlavors.Location = new System.Drawing.Point(300, 48);
            this.comboBoxFlavors.Name = "comboBoxFlavors";
            this.comboBoxFlavors.Size = new System.Drawing.Size(121, 28);
            this.comboBoxFlavors.TabIndex = 4;
            // 
            // checkBoxNuts
            // 
            this.checkBoxNuts.AutoSize = true;
            this.checkBoxNuts.Location = new System.Drawing.Point(448, 23);
            this.checkBoxNuts.Name = "checkBoxNuts";
            this.checkBoxNuts.Size = new System.Drawing.Size(112, 24);
            this.checkBoxNuts.TabIndex = 5;
            this.checkBoxNuts.Text = "Nuts $0.50";
            this.checkBoxNuts.UseVisualStyleBackColor = true;
            // 
            // checkBoxWhippedCream
            // 
            this.checkBoxWhippedCream.AutoSize = true;
            this.checkBoxWhippedCream.Location = new System.Drawing.Point(448, 53);
            this.checkBoxWhippedCream.Name = "checkBoxWhippedCream";
            this.checkBoxWhippedCream.Size = new System.Drawing.Size(193, 24);
            this.checkBoxWhippedCream.TabIndex = 6;
            this.checkBoxWhippedCream.Text = "Whipped Cream $0.50";
            this.checkBoxWhippedCream.UseVisualStyleBackColor = true;
            // 
            // checkBoxCherries
            // 
            this.checkBoxCherries.AutoSize = true;
            this.checkBoxCherries.Location = new System.Drawing.Point(448, 83);
            this.checkBoxCherries.Name = "checkBoxCherries";
            this.checkBoxCherries.Size = new System.Drawing.Size(138, 24);
            this.checkBoxCherries.TabIndex = 7;
            this.checkBoxCherries.Text = "Cherries $0.50";
            this.checkBoxCherries.UseVisualStyleBackColor = true;
            // 
            // buttonOrderNow
            // 
            this.buttonOrderNow.Location = new System.Drawing.Point(648, 12);
            this.buttonOrderNow.Name = "buttonOrderNow";
            this.buttonOrderNow.Size = new System.Drawing.Size(140, 84);
            this.buttonOrderNow.TabIndex = 8;
            this.buttonOrderNow.Text = "Order Now!";
            this.buttonOrderNow.UseVisualStyleBackColor = true;
            this.buttonOrderNow.Click += new System.EventHandler(this.buttonOrderNow_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(648, 102);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(140, 34);
            this.buttonExit.TabIndex = 9;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelFlavor
            // 
            this.labelFlavor.Location = new System.Drawing.Point(312, 22);
            this.labelFlavor.Name = "labelFlavor";
            this.labelFlavor.Size = new System.Drawing.Size(100, 23);
            this.labelFlavor.TabIndex = 10;
            this.labelFlavor.Text = "Flavor?";
            this.labelFlavor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 162);
            this.Controls.Add(this.labelFlavor);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonOrderNow);
            this.Controls.Add(this.checkBoxCherries);
            this.Controls.Add(this.checkBoxWhippedCream);
            this.Controls.Add(this.checkBoxNuts);
            this.Controls.Add(this.comboBoxFlavors);
            this.Controls.Add(this.radioButtonThreeScoop);
            this.Controls.Add(this.radioButtonTwoScoop);
            this.Controls.Add(this.radioButtonOneScoop);
            this.Controls.Add(this.pictureBoxStore);
            this.Name = "Form1";
            this.Text = "Order Menu Screen :)";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStore)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxStore;
        private System.Windows.Forms.RadioButton radioButtonOneScoop;
        private System.Windows.Forms.RadioButton radioButtonTwoScoop;
        private System.Windows.Forms.RadioButton radioButtonThreeScoop;
        private System.Windows.Forms.ComboBox comboBoxFlavors;
        private System.Windows.Forms.CheckBox checkBoxNuts;
        private System.Windows.Forms.CheckBox checkBoxWhippedCream;
        private System.Windows.Forms.CheckBox checkBoxCherries;
        private System.Windows.Forms.Button buttonOrderNow;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelFlavor;
    }
}

