﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Multiple_Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonOrderNow_Click(object sender, EventArgs e)
        {
            {
                double basePrice = 0.0;
                if (radioButtonThreeScoop.Checked) basePrice = 4.00;
                else if (radioButtonTwoScoop.Checked) basePrice = 3.00;
                else if (radioButtonOneScoop.Checked) basePrice = 2.20;

                double toppingsPrice = 0.0;
                if (checkBoxNuts.Checked) toppingsPrice += 0.50;
                if (checkBoxWhippedCream.Checked) toppingsPrice += 0.50;
                if (checkBoxCherries.Checked) toppingsPrice += 0.50;

                double totalPrice = basePrice + toppingsPrice;

                string selectedFlavor = comboBoxFlavors.SelectedItem?.ToString() ?? "None";

                OrderSummaryForm summaryForm = new OrderSummaryForm(totalPrice, selectedFlavor);
                summaryForm.Show();
            }
        }
        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
