﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Multiple_Forms
{
    public partial class OrderSummaryForm : Form
    {
        public OrderSummaryForm(double totalPrice, string flavor)
        {
            InitializeComponent();
            labelOrderSummary.Text = $"Your order total is: ${totalPrice:F2}";
        }
        private void OrderSummaryForm_Load(object sender, EventArgs e)
        {
            //Null
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
