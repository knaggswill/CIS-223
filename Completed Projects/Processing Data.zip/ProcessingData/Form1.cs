﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcessingData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double rainInches = double.Parse(textBoxRain.Text);
                double temperature = double.Parse(textBoxTemperature.Text);
                double conversionRatio;
                if (temperature <= 34) 
                {
                    conversionRatio = 10; 

                    //Numeric Constant defined above as 10
                }
                else if (temperature > 28 && temperature <= 40)
                { 
                    conversionRatio = 10;

                    //Numeric constant defined above as 10
                }
                else
                {
                    conversionRatio = 7; 
                    
                    //Logic above for waermer temps
                }
                double snowInches = rainInches * conversionRatio;
                outputLabel.Text = snowInches.ToString("F2");

                //Conversion formula above
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid number.");

                //Catch exception of invalid ints
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "";
            textBoxTemperature.Text = "";
            textBoxRain.Text = "";
        }
    }
}
        