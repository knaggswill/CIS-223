﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Working_with_Strings
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Void
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            string input = txtPhoneNumber.Text;

            if (IsValidFormat(input))
            {
                string numericPhoneNumber = ConvertToNumeric(input);
                lblResult.Text = $"Converted Number: {numericPhoneNumber}";
            }
            else
            {
                MessageBox.Show("Invalid format. Please use format XXX-XXXXXXX.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private bool IsValidFormat(string input)
            {
                return input.Length == 11 && input[3] == '-';
            }

            private string ConvertToNumeric(string phoneNumber)
            {
                string[] letterToNumberMap = new string[]
                {
                "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"
                };
                string result = string.Empty;

                foreach (char c in phoneNumber)
                {
                    if (char.IsLetter(c))
                    {
                        result += GetNumberForLetter(c);
                    }
                    else
                    {
                        result += c;
                    }
                }

                return result;
            }

            private char GetNumberForLetter(char letter)
            {
                letter = char.ToUpper(letter); // Convert letter to uppercase
                string[] letterToNumberMap = new string[]
                {
                "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"
                };

                for (int i = 0; i < letterToNumberMap.Length; i++)
                {
                    if (letterToNumberMap[i].Contains(letter))
                    {
                        return (char)('2' + i);
                    }
                }
                return '0';
            }

        private void lblResult_Click(object sender, EventArgs e)
        {
            //Void
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void txtPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            //Void
        }
    }
}
//Have a great day :))))
